#!/bin/bash

rosparam load spaces.yaml

for i in `seq 1 50`;
do
	rosparam load ijrr_rigid_body.yaml /rrt_$i
	rosparam set /rrt_$i/task_planner/planners/planner1/steering true
	rosparam set /rrt_$i/task_planner/planners/planner1/type sst
	rosparam set /rrt_$i/task_planner/planners/planner1/delta_drain 0
	rosparam set /rrt_$i/task_planner/planners/planner1/delta_near 0
	rosparam set /rrt_$i/problems/problem1/specification/local_planner/type bvp_local_planner
	rosparam set /rrt_$i/random_seed $i
done    
for i in `seq 1 50`;
do
	rosparam load ijrr_rigid_body.yaml /rrt_star_$i
	rosparam set /rrt_star_$i/task_planner/planners/planner1/steering true
	rosparam set /rrt_star_$i/task_planner/planners/planner1/type rrt_star
	rosparam set /rrt_star_$i/task_planner/planners/planner1/delta_drain 0
	rosparam set /rrt_star_$i/task_planner/planners/planner1/delta_near 0
	rosparam set /rrt_star_$i/problems/problem1/specification/local_planner/type bvp_local_planner
	rosparam set /rrt_star_$i/random_seed $i
done   
for i in `seq 1 50`;
do
	rosparam load ijrr_rigid_body.yaml /sst_$i
	rosparam set /sst_$i/task_planner/planners/planner1/steering true
	rosparam set /sst_$i/task_planner/planners/planner1/type sst
	rosparam set /sst_$i/task_planner/planners/planner1/delta_drain 2
	rosparam set /sst_$i/task_planner/planners/planner1/delta_near 4
	rosparam set /sst_$i/problems/problem1/specification/local_planner/type time_varying_local_planner
	rosparam set /sst_$i/random_seed $i
done   